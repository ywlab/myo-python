var classmyo_1_1_device_listener =
[
    [ "~DeviceListener", "classmyo_1_1_device_listener.html#a7fc9e0a3c86a9023e420577465983cb4", null ],
    [ "onAccelerometerData", "classmyo_1_1_device_listener.html#ad983924f2a2b0eb3c18047a52ed3b5fb", null ],
    [ "onArmSync", "classmyo_1_1_device_listener.html#a6fb8c8e8de652c6fbb416a4cb1441db0", null ],
    [ "onArmUnsync", "classmyo_1_1_device_listener.html#a5d34d631cffc21c74be26f0f59c0fa84", null ],
    [ "onBatteryLevelReceived", "classmyo_1_1_device_listener.html#ad29597d9acec7a1a9f1ae360f539f952", null ],
    [ "onConnect", "classmyo_1_1_device_listener.html#a29ab3696d66a787e296017ce74abcee9", null ],
    [ "onDisconnect", "classmyo_1_1_device_listener.html#a83fd365a88abf5dc947374e69459c5cb", null ],
    [ "onEmgData", "classmyo_1_1_device_listener.html#a79f2abac09f0408c859cccf991d5294a", null ],
    [ "onGyroscopeData", "classmyo_1_1_device_listener.html#ad9ac9d1d839804022c759b6f225a0032", null ],
    [ "onLock", "classmyo_1_1_device_listener.html#a9b770ada17d8cc11b3e452164cf82499", null ],
    [ "onOrientationData", "classmyo_1_1_device_listener.html#adaee14d3c4f9df61899ac8aa95b6bbc6", null ],
    [ "onPair", "classmyo_1_1_device_listener.html#af2b09ca659ea0a2f604117d1d49af2e1", null ],
    [ "onPose", "classmyo_1_1_device_listener.html#a2d2e3595a1ec313c770b7efce374803f", null ],
    [ "onRssi", "classmyo_1_1_device_listener.html#a78c404fbd7649e11aed5c4d10705df74", null ],
    [ "onUnlock", "classmyo_1_1_device_listener.html#aa70fd3615c1a40bee415b8085201a105", null ],
    [ "onUnpair", "classmyo_1_1_device_listener.html#afd9a510fbf547fa764a7e80f733b1081", null ],
    [ "onWarmupCompleted", "classmyo_1_1_device_listener.html#a8661d1a2e3a0813788fbbd70a3520256", null ]
];