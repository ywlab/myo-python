var searchData=
[
  ['unlock',['unlock',['../classmyo_1_1_myo.html#abc7c0f4efe0914ea4c006a7d2114fb79',1,'myo::Myo']]],
  ['unlocktype',['UnlockType',['../classmyo_1_1_myo.html#a46497cc40a6ea496f1022643adfe71cc',1,'myo::Myo']]]
];
